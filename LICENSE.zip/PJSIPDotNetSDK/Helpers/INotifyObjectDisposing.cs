﻿namespace PJSIPDotNetSDK.Helpers
{
    interface INotifyObjectDisposing
    {
        event GenericHandlers.ObjectDisposingHandler ObjectDisposing;
    }
}
